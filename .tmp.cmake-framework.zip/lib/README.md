# /lib
Contains output of compiled static and dynamic libraries
