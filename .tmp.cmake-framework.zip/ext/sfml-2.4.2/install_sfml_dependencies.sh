#!/usr/bin/env bash

# On Windows and Mac dependencies are provided with SFML
# On linux we need to install them

sudo apt install libvorbis-dev
